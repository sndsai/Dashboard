import React, { useState } from 'react';

function App() {
  const [barChartData, setBarChartData] = useState([
    { label: 'May', value: 45 },
    { label: 'June', value: 22 },
    { label: 'July', value: 38 },
    { label: 'August', value: 50 },
  ]);

  const [pieChartData, setPieChartData] = useState([
    { label: 'Category X', value: 60 },
    { label: 'Category Y', value: 25 },
    { label: 'Category Z', value: 35 },
  ]);

  return (
    <div className="App">
      <h1>Interactive Dashboard</h1>
      <div className="Charts">
        <BarChart data={barChartData} />
        <PieChart data={pieChartData} />
      </div>
    </div>
  );
}

export default App;

function BarChart({ data }) {
  return (
    <div className="Chart">
      <h2>Monthly Sales</h2>
      <div className="BarChart">
        {data.map((item, index) => (
          <div key={index} style={{ height: item.value * 5 + 'px' }}>
            <p>{item.label}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

function PieChart({ data }) {
  const total = data.reduce((sum, item) => sum + item.value, 0);

  return (
    <div className="Chart">
      <h2>Category Distribution</h2>
      <div className="PieChart">
        {data.map((item, index) => (
          <div key={index} className="Slice" style={{ transform: `rotate(${(360 * item.value) / total}deg)` }}>
            <p>{item.label}</p>
          </div>
        ))}
      </div>
    </div>
  );
}